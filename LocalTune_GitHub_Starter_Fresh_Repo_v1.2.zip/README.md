# LocalTune — GitHub APK Build Starter

This repository contains the Android source project and a GitHub Actions workflow.
You can build the APK using GitHub from your Android phone; Android Studio is not
required on your phone.

## Create a fresh repository from your phone

1. Create a new repository on GitHub. `LocalTune` is a suitable name.
2. Choose **Public** (recommended for the simplest GitHub Actions setup).
3. Do not create a README, `.gitignore`, or license on GitHub if you plan to upload
   this starter ZIP as the first commit.
4. Download and extract this ZIP on your phone.
5. Upload the **contents** of the extracted `LocalTune_GitHub_Starter` folder to
   the repository root. Do not upload the ZIP file itself and do not put everything
   inside an extra nested folder.
6. Confirm that `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`,
   `app/`, and `.github/` are visible at the top level of the repository.
7. Open the **Actions** tab. Select **Build LocalTune APK** and tap **Run workflow**.
   A push to the `main` branch also starts the workflow automatically.

## Download the APK

1. Open the completed workflow run in **Actions**.
2. Scroll to **Artifacts**.
3. Download `LocalTune-debug-apk`.
4. Extract that downloaded artifact ZIP.
5. Install `app-debug.apk` on your Android phone. Android may ask you to allow
   installation from the browser or file manager you used.

## Project structure

```text
.
├── .github/
│   └── workflows/
│       └── build-apk.yml
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/localtune/
│       │   ├── MainActivity.kt
│       │   └── PlaybackService.kt
│       └── res/values/styles.xml
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```

## Notes

- The workflow builds the project directly from the repository. It does not try
  to unzip a second project ZIP.
- The Kotlin property that conflicted with Android's `getMainExecutor()` method
  has been renamed to `playerMainExecutor`.
- This workflow creates a debug APK for testing. A Play Store release needs a
  separately configured signed release build.


## LocalTune v1.2 functionality fix

This revision makes the connected MediaController observable to Jetpack Compose.
Previously, the controller was a normal Activity property, so Compose effects could
remain attached to a null controller after the asynchronous connection completed.
The app now recomposes when the controller connects, logs connection failures, and
requests/scans the local audio library on first launch (Android still displays its
standard permission prompt).
